import React from 'react'

class Dashboard extends React.Component {
    render() {
        return (
            <div className="app-admin-dashboard">
                 add
            </div>
        )
    }
}

export default Dashboard;