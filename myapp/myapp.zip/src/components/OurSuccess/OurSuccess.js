import React from "react";

import Content from "./Content";

class OurSuccess extends React.Component {
  render() {
    return (
      <div className="jumbotron-masthead jumbotron-fluid img-bg-our-success">
          <Content />
      </div>
    );
  }
}

export default OurSuccess;
