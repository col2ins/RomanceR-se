import React from "react";

import Content from "./Content";

class Contact extends React.Component {
  render() {
    return (
      <div className="jumbotron-masthead jumbotron-fluid text-align-left bg-very-soft-orange-12-5">
        <Content />
      </div>
    );
  }
}

export default Contact;
