import React from "react";

import Content from "./Content";

class Partners extends React.Component {
  render() {
    return (
      <div className="bg-no-color padding-bottom-100">
          <Content />
      </div>
    );
  }
}

export default Partners;
