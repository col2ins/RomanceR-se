import React from "react";
import { Container } from "react-bootstrap";

class Title extends React.Component {
  render() {
    return (
      <Container className="margin-top-secondary">
        <div>
          {" "}
          <h4 className="h4-masthead montserrat-semibold color-dark-75">
            Vestibulum tristique erat at accumsan cursus?
          </h4>
          <p className="p-masthead-primary montserrat-medium color-dark-50">
            Ut pulvinar magna purus, sit amet posuere tortor lacinia non. Ut
            turpis leo, feugiat nec finibus non, dignissim cursus ipsum. Aliquam
            erat volutpat. Mauris ut viverra tellus. Donec vel mauris turpis. In
            aliquam consequat velit quis eleifend. Aenean vitae magna iaculis,
            bibendum mi id, and interdum turpis.
          </p>
        </div>
        <div className="margin-top-tertiary">
          {" "}
          <h4 className="h4-masthead montserrat-semibold color-dark-75">
            Vestibulum tristique erat at accumsan cursus?
          </h4>
          <p className="p-masthead-primary montserrat-medium color-dark-50">
            Ut pulvinar magna purus, sit amet posuere tortor lacinia non. Ut
            turpis leo, feugiat nec finibus non, dignissim cursus ipsum. Aliquam
            erat volutpat. Mauris ut viverra tellus. Donec vel mauris turpis. In
            aliquam consequat velit quis eleifend. Aenean vitae magna iaculis,
            bibendum mi id, and interdum turpis.
          </p>
        </div>
        <div className="margin-top-tertiary">
          {" "}
          <h4 className="h4-masthead montserrat-semibold color-dark-75">
            Vestibulum tristique erat at accumsan cursus?
          </h4>
          <p className="p-masthead-primary montserrat-medium color-dark-50">
            Ut pulvinar magna purus, sit amet posuere tortor lacinia non. Ut
            turpis leo, feugiat nec finibus non, dignissim cursus ipsum. Aliquam
            erat volutpat. Mauris ut viverra tellus. Donec vel mauris turpis. In
            aliquam consequat velit quis eleifend. Aenean vitae magna iaculis,
            bibendum mi id, and interdum turpis.
          </p>
        </div>
        <div className="margin-top-tertiary">
          {" "}
          <h4 className="h4-masthead montserrat-semibold color-dark-75">
            Vestibulum tristique erat at accumsan cursus?
          </h4>
          <p className="p-masthead-primary montserrat-medium color-dark-50">
            Ut pulvinar magna purus, sit amet posuere tortor lacinia non. Ut
            turpis leo, feugiat nec finibus non, dignissim cursus ipsum. Aliquam
            erat volutpat. Mauris ut viverra tellus. Donec vel mauris turpis. In
            aliquam consequat velit quis eleifend. Aenean vitae magna iaculis,
            bibendum mi id, and interdum turpis.
          </p>
        </div>
        <div className="margin-top-tertiary">
          {" "}
          <h4 className="h4-masthead montserrat-semibold color-dark-75">
            Vestibulum tristique erat at accumsan cursus?
          </h4>
          <p className="p-masthead-primary montserrat-medium color-dark-50">
            Ut pulvinar magna purus, sit amet posuere tortor lacinia non. Ut
            turpis leo, feugiat nec finibus non, dignissim cursus ipsum. Aliquam
            erat volutpat. Mauris ut viverra tellus. Donec vel mauris turpis. In
            aliquam consequat velit quis eleifend. Aenean vitae magna iaculis,
            bibendum mi id, and interdum turpis.
          </p>
        </div>
      </Container>
    );
  }
}

export default Title;
